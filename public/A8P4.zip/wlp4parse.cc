#include <iostream>
#include <string>
#include <sstream>
#include <iomanip>
#include <cctype>
#include <algorithm>
#include <utility>
#include <set>
#include <vector>
#include <stack>
#include <queue>
#include <fstream>
#include "wlp4parse.h"
#include <stdexcept>
using namespace std;


InfoPackage getrules() {
  //terminals
  //all inputs must be in terminals, they can't be intermediates.
	ifstream grammarinput("wlp4grammar.txt");
	int numterminals=0;
	grammarinput>>numterminals;
	string blankline;
	getline(grammarinput,blankline);
	vector <string> symbols;
	vector <string> terminals;
	for(int i=0;i<numterminals;i++){
		string terminal;
		getline(grammarinput, terminal);
		symbols.push_back(terminal);
		terminals.push_back(terminal);
	}
  //symbols
	int numsymbols;
	grammarinput>>numsymbols;
	getline(grammarinput, blankline);
	for(int i=0;i<numsymbols;i++){
		string symbol;
		getline(grammarinput, symbol);
		symbols.push_back(symbol);
	}
  //sort the symbols
	string END;
	getline(grammarinput, END);
	sort(symbols.begin(),symbols.end());
	sort(terminals.begin(),terminals.end());
  //rules 
	int numGrammars;
	grammarinput>>numGrammars;
	getline(grammarinput,blankline);
	vector <string> LHS; //LHS of the rule
	vector <vector<string>> RHS; //RHS of the rule
	for(int i=0;i<numGrammars;i++){
		string grammar;
		getline(grammarinput, grammar);
		stringstream inputline (grammar);
		string L;
		inputline >> L;
		string Rc;
		vector <string> R;
		while(inputline >> Rc){
			R.push_back(Rc);
		}
		LHS.push_back(L);
		RHS.push_back(R);
	}
	
	InfoPackage myrules{LHS,RHS};
	return myrules;
}


int BinarySearch(vector <string> myvec, string target){
	if(myvec.size() == 0){
		return -1;
	}
	if(target < myvec[0]){
		return -1;
	}
	if(target > myvec[myvec.size()-1]){
		return -1;
	}
	int low = 0;
	int high = myvec.size()-1;
	
	while(low<high){
		int mid=(low+high)/2;
		if(myvec[mid]<target){
			low=mid+1;
		}
		else if(myvec[mid]>target){
			high=mid;
		}
		else{
			return mid;
		}
	}
	
	if(myvec[low] == target){
		return low;
	}
	return -1;
}
