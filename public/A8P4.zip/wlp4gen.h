#ifndef wlp4gen_H
#define wlp4gen_H
#include <vector>
#include <stack>
#include <string>
#include "wlp4parse.h"
using namespace std;
//procedures, procedures and main
int TopProcedures(node * root, vector <string> & LHS, vector <vector <string>> & RHS,vector<pair<string, vector<int>>> & procedures);

//params
void params(node * paramtree, vector<pair<int, string>> & MethodDcls);

//paramlist
void paramlist(node * paramtree, vector<pair<int, string>> & MethodDcls);

//dcl, returns the type, variable name pair
pair<int, string> dcl(node * dclstree);

//return the type of the variable. 0 for int and 1 for int*
int type(node * typetree);

//This could be the name of the function, and also variable name. Variables have precidence
int ID(node * root, vector<pair<int, string>> & MethodDcls,vector<pair<string, vector<int>>>  & procedures, bool isprocedures);

//Add all declearations of the dcls tree to the vector
void dcls(node * dclstree, vector<pair<int, string>> & MethodDcls);


//add Parameter to variable vector
void addParamToVec(pair<int, string> newvar, vector<pair<int, string>> & MethodDcls, int registerNumber);

//Add varaibe to the vector
void addVarToVec(pair<int, string> newvar, vector<pair<int, string>> & MethodDcls);

//statements
void statements(node * root, vector<pair<int, string>> & MethodDcls,vector<pair<string, vector<int>>>  & procedures);

//statement
void statement(node * root, vector<pair<int, string>> & MethodDcls,vector<pair<string, vector<int>>>  & procedures);

//Condition for the if/while statement
void test(node * root, vector<pair<int, string>> & MethodDcls,vector<pair<string, vector<int>>>  & procedures);

//Handles expr, return the type of the expr
int expr(node * root, vector<pair<int, string>> & MethodDcls, vector<pair<string, vector<int>>>  & procedures);

//Hanldes term, return the type of the term
int term(node * root, vector<pair<int, string>> & MethodDcls, vector<pair<string, vector<int>>>  & procedures);

//Handles factor, return the type of the factor
int factor(node * root, vector<pair<int, string>> & MethodDcls, vector<pair<string, vector<int>>>  & procedures);

//handles arglist, return a list of args
stack<int> arglist(node * root, vector<pair<int, string>> & MethodDcls,vector<pair<string, vector<int>>>  & procedures);

//handles lvalue, return the type of the lvalue
int lvalue(node * root, vector<pair<int, string>> & MethodDcls,vector<pair<string, vector<int>>>  & procedures);

//helpers

//return the name of the variable
string getID(node * IDtree);

//check if the args type are for functions
void CorrectArgs(int funIndex, vector<int> & thisfunargs,vector<pair<string, vector<int>>>  & procedures);

vector<int> stackTovec(stack <int> given);

void printmethod(string funName, vector <pair<int, string>> MethodDcls);
void printvariable(pair<int, string> variable);
void AddMethod(string proceName, vector<pair<string, vector<int>>>  & procedures, vector <pair<int, string>> & MethodDcls);
void printlocals(vector <pair<int, string>> & MethodDcls);
//int:0 int* 1
int findvar(string varname, vector<pair<int, string>> & MethodDcls);
node * buildtree(vector <string> & LHS, vector <vector<string>> & RHS);
int findRuleUsed(vector <string> & LHS, vector <vector<string>> & RHS, string L, vector <string> & R);
void freetree(node * root);
int Hasprocedure(string proceName, vector<pair<string, vector<int>>>  & procedures);

#endif

