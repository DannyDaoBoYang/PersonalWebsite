#ifndef regfunctions_H
#define regfunctions_H
#include <iostream>
using namespace std;
void pushReg(int regnumber);
void popReg(int regnumber);

void initReg(int regnumber, int offset);
void updateReg(int regnumber, int offset);

void popStack();
#endif
