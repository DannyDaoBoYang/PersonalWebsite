#include <iostream>
#include <string>
#include <sstream>
#include <iomanip>
#include <cctype>
#include <algorithm>
#include <utility>
#include <set>
#include <vector>
#include <stack>
#include <queue>
#include <fstream>
#include <stdexcept>
#include "wlp4gen.h"
#include "wlp4parse.h"
#include "registerFunctions.h"
using namespace std;
int main(){
	InfoPackage Grammar=getrules();
	bool fuckedDoNotGo=false;
	node * tree;
	try{
		tree = buildtree(Grammar.LHS, Grammar.RHS);
	}catch(exception e){
		cerr<<"ERROR"<<endl;
		fuckedDoNotGo=true;
		
	}
	if(!fuckedDoNotGo){
	cout<<".import print"<<endl;
	cout<<"lis $10"<<endl;
	cout<<".word print"<<endl;
	cout<<"lis $4"<<endl;
	cout<<".word 4"<<endl;
	vector<pair<string, vector<int>>> procedures;
	try{
		TopProcedures(tree, Grammar.LHS, Grammar.RHS, procedures);
	}catch(exception e){
		cerr<<"ERROR"<<e.what()<<endl;
		
	}
	}
	freetree(tree);
	
}
//
//int is 0
//int* is 1
//other is 2
//
int TopProcedures(node * root, vector <string> & LHS, vector <vector <string>> & RHS, vector<pair<string, vector<int>>>  & procedures){
	if(!root->token){
		if(LHS[root->rule] == "procedure"){
		//INT ID LPAREN params RPAREN LBRACE dcls statements RETURN expr SEMI RBRACE
		// 0   1   2       3      4     5      6    7          8     9    10   11
			
			vector <pair<int, string>> MethodDcls;
			params(root->children[3], MethodDcls);
			AddMethod(root->children[1]->tokenstring, procedures, MethodDcls); //Add prcedure params
			printmethod(root->children[1]->tokenstring, MethodDcls);
			dcls(root->children[6], MethodDcls);
			printlocals(MethodDcls);
			statements(root->children[7],MethodDcls, procedures);
			if(expr(root->children[9],MethodDcls, procedures)!=0) throw invalid_argument("Wrong Return Type");
	 
		}
		else if(LHS[root->rule]== "main"){
		//INT WAIN LPAREN dcl COMMA dcl RPAREN LBRACE dcls statements RETURN expr SEMI RBRACE
		// 0    1   2      3     4    5    6    7      8     9          10    11   12   13   
			//set fram pointer
			cout<<"sub $29, $30, $4"<<endl;

			vector <pair<int, string>> MethodDcls;

			pair<int, string> param1 = dcl(root->children[3]);
			addParamToVec(param1, MethodDcls, 1);

			pair<int, string> param2 = dcl(root->children[5]);
			addParamToVec(param2, MethodDcls, 2);
		
			if(param2.first!=0)throw invalid_argument("Wrong Main params");
		
			// dcls(root->children[8], MethodDcls); don't need for now
			
			//printlocals(MethodDcls);

			//statements(root->children[9], MethodDcls, procedures);
			
			//return Expression
			int returnExpr = expr(root->children[11], MethodDcls, procedures);
			
			if(returnExpr!=0)  throw invalid_argument("Wrong Return Type");

			for(int i=0;i<MethodDcls.size();i++){
				popStack();
			}
			cout<<"jr $31"<<endl;
		}
		else {
		for(int i=0;i<root->children.size();i++){
			TopProcedures(root->children[i],LHS,RHS, procedures);
		}
		}
	}
	return 0;
}

void params(node * paramtree, vector<pair<int,string>> & MethodDcls){ //params
	if(paramtree->children.size()!=0){
		paramlist(paramtree->children[0], MethodDcls);
	}
}
void paramlist(node * paramtree, vector <pair<int,string>> & MethodDcls){//paramlist
	pair<int,string> variable = dcl(paramtree->children[0]);
	addVarToVec(variable, MethodDcls);
	if(paramtree->children.size() == 3){//dcl COMMA paramlist
		paramlist(paramtree->children[2], MethodDcls);
	}
}


string getID(node * IDtree){
	return IDtree->tokenstring;
}
void printmethod(string funName, vector <pair<int, string>> MethodDcls){
	cerr<<funName<<":";	
	for(int i=0;i<MethodDcls.size();i++){
		if(MethodDcls[i].first==0)
		cerr<<" int";
		else cerr<<" int*";
	}
	cerr<<endl;
}
void printlocals(vector <pair<int, string>> & MethodDcls){
	for(int i=0;i<MethodDcls.size();i++){
		printvariable(MethodDcls[i]);
	}
}
void printvariable(pair<int, string> variable){
	if(variable.first==0){
			cerr<<variable.second<<" int"<<endl;
		}
		else{
			cerr<<variable.second<<" int*"<<endl;
	}
}
void AddMethod(string proceName, vector<pair<string, vector<int>>>  & procedures, vector <pair<int, string>> & MethodDcls){
	for(int i=0;i<procedures.size();i++){
		if(Hasprocedure(proceName,procedures)>=0){
		cerr<<"MD"<<endl;
		 throw invalid_argument("Multiple Definition");
		}
	}
	vector <int> typesInMethod;
	for(int i=0;i<MethodDcls.size();i++){
		typesInMethod.push_back(MethodDcls[i].first);
	}
	pair <string, vector<int>> thisMethod;
	thisMethod.first = proceName;
	thisMethod.second = typesInMethod;
	procedures.push_back(thisMethod);
}
int Hasprocedure(string proceName, vector<pair<string, vector<int>>>  & procedures){
	for(int i=0;i<procedures.size();i++){
		if(procedures[i].first == proceName) return i;
	}
	return -1;
}
int type(node * typetree){
	if(typetree->children.size()==2){
		return 1;
	}
	else{
		return 0;	
	}
}
void dcls(node * dclstree, vector<pair<int, string>> & MethodDcls){
	if(dclstree->rule == 12 || dclstree->rule == 13){
		dcls(dclstree->children[0], MethodDcls);
		
		pair<int, string> newvar = dcl(dclstree->children[1]);
		if(dclstree->rule == 12 && newvar.first!=0) throw invalid_argument("Wrong Type");
		if(dclstree->rule == 13 && newvar.first!=1) throw invalid_argument("Wrong Type");
		addVarToVec(newvar,MethodDcls);
		
	}
}
pair<int, string> dcl(node * dcltree){
	pair<int, string> newvariable;
	newvariable.first = type(dcltree->children[0]);
	newvariable.second = getID(dcltree->children[1]);
	return newvariable;
}
void statements(node * root, vector<pair<int, string>> & MethodDcls,vector<pair<string, vector<int>>>  & procedures){	
	if(root->children.size()>0){
		statements(root->children[0],MethodDcls, procedures);
		statement(root->children[1], MethodDcls,procedures);
	}
}
void statement(node * root, vector<pair<int, string>> & MethodDcls,vector<pair<string, vector<int>>>  & procedures){
	if(root->rule == 17){ //assignment
		int lvalue1 = lvalue(root->children[0],MethodDcls, procedures);
		int expr2 = expr(root->children[2],MethodDcls, procedures);
		if(lvalue1!=expr2) throw invalid_argument("Assignment Type Missmatch");
	}else if(root->rule == 18){ //IF
		test(root->children[2],MethodDcls,procedures);
		statements(root->children[5],MethodDcls,procedures);
		statements(root->children[9],MethodDcls,procedures);
	}else if(root->rule == 19){ //WHILE
		test(root->children[2],MethodDcls,procedures);
		statements(root->children[5],MethodDcls,procedures);
	}else if(root->rule == 20){ //PRINTLN ( expr ) ;
		int expr1 = expr(root->children[2],MethodDcls,procedures);
		cout<<"add $1, $3, $0"<<endl;
		pushReg(4);
		pushReg(31);
		cout<<"jalr $10"<<endl;
		popReg(31);
		popReg(4);
	if(expr1!=0) throw invalid_argument("Assignment Type Missmatch");
	}else if(root->rule == 21){ //DELETE
		int expr1 = expr(root->children[3],MethodDcls,procedures);
		if(expr1!=1) throw invalid_argument("Assignment Type Missmatch");
	}
}
void test(node * root, vector<pair<int, string>> & MethodDcls,vector<pair<string, vector<int>>>  & procedures){//22
	int expr1=expr(root->children[0],MethodDcls,procedures);
	int expr2=expr(root->children[2],MethodDcls,procedures);
	if(expr1 != expr2){
		throw invalid_argument("Test Type Missmatch");
	}
}
int expr(node * root, vector<pair<int, string>> & MethodDcls,vector<pair<string, vector<int>>>  & procedures){
	if(root->rule == 28){//term
		return term(root->children[0],MethodDcls, procedures);
	}
	else if(root->rule == 29){// expr PLUS term
		int expr1 = expr(root->children[0], MethodDcls, procedures);
		pushReg(3);
	
		int term2 = term(root->children[2], MethodDcls, procedures);

		if(expr1 + term2 > 1) throw invalid_argument("Test Type Missmatch");
		popReg(5);

		cout<<"add $3, $5, $3"<<endl;		
		return expr1 + term2;
	}
	else if(root->rule == 30){//expr Minus term
		int expr1 = expr(root->children[0], MethodDcls, procedures);
		pushReg(3);
		
		int term2 = term(root->children[2], MethodDcls, procedures);
		
		
		if(expr1 - term2 < 0) throw invalid_argument("Test Type Missmatch");
		popReg(5);		
	
		cout<<"sub $3, $5, $3"<<endl;	
		return expr1 - term2;
	}
	return -1;
}
int term(node * root, vector<pair<int, string>> & MethodDcls,vector<pair<string, vector<int>>>  & procedures){
	if(root->rule == 31){// factor
		return factor(root->children[0], MethodDcls, procedures);
	} else if(root->rule == 32 ||root->rule == 33 ||root->rule == 34 ){// times, divide or percent
		int term1 = term(root->children[0], MethodDcls, procedures);
		pushReg(3);
		int factor2 = factor(root->children[2], MethodDcls, procedures);
		popReg(5);

		if(term1!=0||factor2!=0) throw invalid_argument("Not valid Types");
		if(root->rule == 32){
			cout<<"mult $5, $3"<<endl;
			cout<<"mflo $3"<<endl;
		}
		if(root->rule == 33){
			cout<<"div $5, $3"<<endl;
			cout<<"mflo $3"<<endl;	
		}
		if(root->rule == 34){
			cout<<"div $5, $3"<<endl;
			cout<<"mfhi $3"<<endl;	
		}		
		return 0;
	}
	return -1;
	
}
int factor(node * root, vector<pair<int, string>> & MethodDcls,vector<pair<string, vector<int>>>  & procedures){
	
		if(root->rule == 35){//ID
			
			return ID(root->children[0],MethodDcls, procedures, false);
		}
		else if(root->rule == 36){//NUM
			//Load NUM into $3
			cout<<"lis $3"<<endl;
			cout<<".word "<<root->children[0]->tokenstring<<endl; 
			return 0;
		}
		else if(root->rule == 37){//NULL
			return 1;
		}
		else if(root->rule == 38){//LPAREN expr RPAREN
			return expr(root->children[1],MethodDcls, procedures);
		}
		else if(root->rule == 39){//AMP lvalue
			if(lvalue(root->children[1],MethodDcls,procedures) == 0) return 1;
			else throw invalid_argument("type missmatch");
		}
		else if(root->rule == 40){//Star factor
			if(factor(root->children[1],MethodDcls,procedures) == 1) return 0;
			else throw invalid_argument("type missmatch");
		}		
		else if(root->rule == 41){//New int ( epxr )
			if(expr(root->children[3], MethodDcls, procedures) == 0) return 1;
			else throw invalid_argument("type missmatch");
		}
		else if( root->rule == 42 ){//ID ( )
			int funIndex = ID(root->children[0],MethodDcls, procedures, true);
			vector<int> thisfunargs;
			CorrectArgs(funIndex, thisfunargs, procedures);
			return 0;
		}
		else if(root->rule == 43){ // function calls ID(arglist)
			int funIndex = ID(root->children[0],MethodDcls, procedures, true);
			vector<int> thisfunargs= stackTovec(arglist(root->children[2], MethodDcls, procedures));
			CorrectArgs(funIndex, thisfunargs, procedures);
			return 0;
		}
		
	return 0;
}
void CorrectArgs(int funIndex, vector<int> & thisfunargs,vector<pair<string, vector<int>>>  & procedures){
	if(funIndex == -1){
		throw invalid_argument("no such function");
	}
	if(procedures[funIndex].second.size()!=thisfunargs.size())throw invalid_argument("no such function");
	for(int i=0;i<procedures[funIndex].second.size();i++){
		if(procedures[funIndex].second[i]!= thisfunargs[i])throw invalid_argument("argtype missmatch");
	}
	
}
vector<int> stackTovec(stack <int> given){
	vector <int> mynewvec;
	while(given.size()!=0){
		mynewvec.push_back(given.top());
		given.pop();
	}
	return mynewvec;
}
stack<int> arglist(node * root, vector<pair<int, string>> & MethodDcls,vector<pair<string, vector<int>>>  & procedures){
	
	if(root->rule == 44){//expr
		stack<int> myargs;
		myargs.push(expr(root->children[0], MethodDcls, procedures));
		return myargs;
	}
	else{//expr COMMA arglist
		stack <int> myargs = arglist(root->children[2],MethodDcls, procedures);
		myargs.push(expr(root->children[0], MethodDcls, procedures));
		return myargs;
	}
}
int lvalue(node * root, vector<pair<int, string>> & MethodDcls,vector<pair<string, vector<int>>>  & procedures){
	if(root->rule == 46){
		return ID(root->children[0], MethodDcls, procedures, false);
	}else if(root->rule == 47){//star factor
		if(factor(root->children[1],MethodDcls, procedures) != 1) throw invalid_argument("type missmatch");
		return 0;
	}else if(root->rule == 48){
		return lvalue(root->children[1],MethodDcls, procedures);
	}
	return -1;
}
int ID(node * root, vector<pair<int, string>> & MethodDcls,vector<pair<string, vector<int>>>  & procedures, bool isprocedures){
	if(isprocedures){
		int functionIndex = Hasprocedure(root->tokenstring, procedures);
		if(functionIndex < 0){
			throw invalid_argument("No such procedure");
		}
		if(findvar(root->tokenstring, MethodDcls)!=-1){
			throw invalid_argument("It's a variable");
		}
		return functionIndex;
	}
	else{	
		int type = findvar(root->tokenstring, MethodDcls);
		if(type == -1)
		throw invalid_argument("No such variable");
		return type;
	}
}
int findvar(string varname, vector<pair<int, string>> & MethodDcls){
	for(int i=0;i<MethodDcls.size();i++){
		if(MethodDcls[i].second == varname){
			cout<<"lw $3, "<<i*(-4)<<"($29)"<<endl;
			return MethodDcls[i].first;
		}
	}
	return -1;
}
void addParamToVec(pair<int, string> newvar, vector<pair<int, string>> & MethodDcls, int registerNumber){
	cout<<"sw $"<<registerNumber<<", "<<(int)(MethodDcls.size())*(-4)<<"($29)"<<endl;	
	cout<<"sub $30, $30, $4"<<endl;

	if(findvar(newvar.second, MethodDcls)>=0){
		throw invalid_argument("Duplicate Defination");
	}
	MethodDcls.push_back(newvar);
	
}
void addVarToVec(pair<int, string> newvar, vector<pair<int, string>> & MethodDcls){
	if(findvar(newvar.second, MethodDcls)>=0){
		throw invalid_argument("Duplicate Defination");
	}
	MethodDcls.push_back(newvar);
	
}
node * buildtree(vector <string> & LHS, vector <vector<string>> & RHS){
	node * root = new node;
	string grammar,L;
	vector <string> R;
	getline(cin, grammar);
	stringstream inputline (grammar);
	inputline >> L;
	while(inputline){
		string tempR;
		inputline >> tempR;
		if(tempR.size() > 0) R.push_back(tempR);
	}
	if(L[0]!=tolower(L[0])){//token
		root->token=true;
		root->type = L;
		root->tokenstring=R[0];
	}
	else{
		root->token=false;
		root->rule = findRuleUsed(LHS,RHS,L,R);
		root->type = L;
		for(int i=0;i<R.size();i++){
			root->children.push_back(buildtree(LHS, RHS));
		}
	}
	
	return root;
}
int findRuleUsed(vector <string> & LHS, vector <vector<string>> & RHS, string L, vector <string> & R){
	for(int i=0;i<LHS.size();i++){

		if(LHS[i]==L && RHS[i].size() == R.size()){
			bool same=true;
			for(int j=0;j<RHS[i].size();j++){
				if(RHS[i][j]!= R[j]) {
					same=false; 
					break;
				}
			}
			if(same)
			return i;
		}
		
	}
	return -1;
}
void freetree(node * root){
	for(int i=0;i<root->children.size();i++){
		freetree(root->children[i]);
	}
	delete root;
}
