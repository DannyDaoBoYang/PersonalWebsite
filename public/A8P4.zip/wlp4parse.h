#ifndef wlp4parse_H
#define wlp4parse_H
#include <vector>
#include <stack>
#include <string>
using namespace std;

struct node{
	vector <node*> children; 
	int rule;
	bool token;
	string type;
	string tokenstring; 
};
struct InfoPackage{
	vector <string> LHS;
	vector <vector<string>> RHS;
	
};
struct edge{
	bool reduce;
	int nextstate;
};
int BinarySearch(vector<string>,string);
int reduce(vector <string>, vector <vector<string>>, int, stack<node>,stack<int>,stack<node>);
void ERRORout(int);
void printrule(vector<string> LHS, vector<vector<string>> RHS, int index);
void printTree(node root, vector <string> LHS, vector <vector <string>> RHS);	
InfoPackage getrules();
#endif
