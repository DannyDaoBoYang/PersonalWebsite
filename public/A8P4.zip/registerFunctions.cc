
#include <iostream>
using namespace std;

void pushReg(int regnumber){
	cout<<"sw $"<<regnumber<<", -4($30)"<<endl;
	cout<<"sub $30, $30, $4"<<endl;
}
void popReg(int regnumber){
	cout<<"lw $"<<regnumber<<", 0($30)"<<endl;
	cout<<"add $30, $30, $4"<<endl;
}

void initReg(int regnumber, int offset){
	cout<<"sw $"<<regnumber<<","<<offset*-4<<"($29)"<<endl;
	cout<<"sub $30, $30, $4"<<endl;
}
void updateReg(int regnumber, int offset){
	cout<<"lw $"<<regnumber<<","<<offset*-4<<"($29)"<<endl;
}

void popStack(){
	cout<<"add $30, $30, $4"<<endl;
}
